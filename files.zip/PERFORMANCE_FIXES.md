# SaarLekha — Performance Fix Pack

Fixes login/data-load latency on the dashboard. Drop these in via Antigravity.
**API response shapes are unchanged** — frontend needs no edits.

## Files

| File | Replaces | What it does |
|---|---|---|
| `prisma.ts` | `backend/src/db/prisma.ts` | Sets RLS context in **1 round trip** instead of 2; removes hardcoded DB passwords; documents the batch (`$transaction`) path. |
| `dashboard.ts` | `backend/src/routes/dashboard.ts` | Runs all `/summary` reads inside **one** transaction; moves CPU work outside it; replaces the unpaginated maintenance scan with a single `DISTINCT ON` query; wraps `/production` in one transaction. |
| `add_performance_indexes.sql` | — (new) | Adds the missing indexes for the hot query paths. |

## Apply order

1. **Rotate credentials first.** The old `prisma.ts` had the `neondb_owner` and
   `saarlekha_app` passwords hardcoded. If that file was ever committed, rotate
   both in Neon. Then set `DATABASE_URL` (env) to the **`saarlekha_app`** role
   connection string — NOT `neondb_owner` (it has BYPASSRLS and disables RLS).
   Optionally set `PG_POOL_MAX` (default 10).
2. Replace `prisma.ts` and `dashboard.ts`.
3. Add the indexes — pick one:
   - **Prisma-native (recommended):** add the `@@index` lines below to
     `schema.prisma`, then `npx prisma migrate dev --name perf_indexes`.
   - **Immediate hotfix:** run `add_performance_indexes.sql` against the DB.
     (Names match Prisma's convention, so adding the `@@index` lines afterward
     stays in sync.)

### `@@index` lines for schema.prisma

```prisma
model ReportEntry {
  // ...
  @@index([company_id, entry_date])
  @@index([department_id])
  @@index([format_version_id])
}
model ProductionRecord {
  // ...
  @@index([company_id, date])
  @@index([operator_id])
  @@index([machine_id])
}
model Manpower {
  // ...
  @@index([company_id])
  @@index([department_id])
}
model JobOrder {
  // ...
  @@index([company_id, status])
  @@index([customer_id])
}
model Machine {
  // ...
  @@index([company_id])
  @@index([department_id])
}
model ReportFormatVersion {
  // ...
  @@index([format_id])
}
model ReportFormat {
  // ...
  @@index([company_id, type])
}
model Customer {
  // ...
  @@index([company_id])
}
model AuditLogEntry {
  // ...
  @@index([company_id, timestamp])
}
```

## Why it's faster

- **Before:** every `prismaTenant.model.op()` opened its own transaction →
  `BEGIN` + 2× `set_config` + query + `COMMIT` = ~5 round trips **per query**.
  `/summary` ran ~7–9 of these **sequentially** = ~35–45 round trips.
- **After:** all reads share one transaction with context set once → ~10 round
  trips total. The two `set_config` calls are also collapsed into one statement
  everywhere (helps every other route too).
- Maintenance summary no longer loads every maintenance entry into Node to pick
  the latest per machine — `DISTINCT ON` does it in the database.
- Aggregation/regex parsing runs after the transaction closes, so it never pins
  a DB connection.

## Assumptions / caveats

- The raw maintenance query assumes **default Prisma table names** (no `@@map`).
  Tables: `"ReportEntry"`, `"ReportFormatVersion"`, `"ReportFormat"`,
  `"Department"`. If you've mapped any, update the quoted identifiers.
- Inside any `$transaction`, use the `tx` argument only — never the outer
  `prismaTenant.*` client (it would run without the tenant GUC under RLS).

## Still worth doing (not in this pack)

- **Move report→production reconciliation to write time.** `/summary` still
  loads all in-range `ReportEntry` rows to fold in "unsynced" machine logs and
  re-parses their JSON payloads on every load. Materialize a `ProductionRecord`
  when a report entry is submitted, then the dashboard just reads aggregates.
  This is the biggest remaining win but touches the submission path, so it's
  scoped separately.
- **Login latency** is bcrypt (cost 12, ~250ms–1s — correct, leave it) plus Neon
  cold starts. If logins are *intermittently* slow, that's the cold start: use a
  keep-warm ping or a non-suspending Neon compute tier. Make sure the API
  container isn't CPU-throttled (that's what makes bcrypt hurt).
