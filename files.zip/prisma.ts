import { PrismaClient, Prisma } from '@prisma/client';
import { PrismaPg } from '@prisma/adapter-pg';
import { AsyncLocalStorage } from 'async_hooks';
import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

/**
 * CREDENTIALS — read this:
 * DATABASE_URL MUST connect as the RLS-enforced application role (e.g. `saarlekha_app`),
 * NOT `neondb_owner`. The owner role has BYPASSRLS, which silently disables every
 * Row-Level Security policy. Put the full connection string (including the app-role
 * password) in the environment. NEVER hardcode credentials in source.
 *
 * If the previous neondb_owner / saarlekha_app passwords were ever committed to git,
 * rotate BOTH in the Neon console now — they should be considered compromised.
 */
let connectionString = process.env.DATABASE_URL || '';
if (!connectionString) {
  throw new Error('DATABASE_URL is not set');
}

/**
 * Use Neon's direct (unpooled) endpoint. Tenant context below is set with
 * transaction-local GUCs (set_config(..., is_local = true)), which is reset on
 * COMMIT/ROLLBACK, so a normal pg pool of direct connections is correct.
 * (Behaviour unchanged from the original — kept intentionally.)
 * If you ever switch to the pooled endpoint, keep it in TRANSACTION pooling mode;
 * session pooling would leak tenant context across requests.
 */
connectionString = connectionString.replace('-pooler', '');

const pool = new pg.Pool({
  connectionString,
  max: Number(process.env.PG_POOL_MAX ?? 10),
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 10_000,
});

const adapter = new PrismaPg(pool);

// Global singleton for NON-tenant queries (auth, super-admin). No RLS wrapping here.
export const prisma = new PrismaClient({ adapter });

// Prevents re-wrapping queries that already run inside an RLS transaction.
const rlsStorage = new AsyncLocalStorage<boolean>();

/**
 * Sets BOTH RLS GUCs in a SINGLE round trip.
 * (Previously this was two separate awaited round trips per query.)
 * set_config(..., true) is transaction-local: it is automatically discarded on
 * COMMIT/ROLLBACK, so each transaction starts clean.
 */
function setTenantContext(
  tx: Prisma.TransactionClient,
  companyId: string,
  role?: string
) {
  return tx.$executeRaw`SELECT
    set_config('app.current_tenant_id', ${companyId}, true),
    set_config('app.current_user_role', ${role ?? ''}, true)`;
}

/**
 * Returns a tenant-scoped Prisma client that enforces RLS at the database level.
 *
 * TWO USAGE PATHS:
 *
 *  1) BATCH (use this for ANY route that runs more than one query):
 *
 *         await client.$transaction(async (tx) => {
 *           const a = await tx.manpower.count();
 *           const b = await tx.jobOrder.count({ where: { status: 'OPEN' } });
 *           return { a, b };
 *         });
 *
 *     Tenant context is set ONCE for all queries inside the callback. You MUST use
 *     the `tx` handed to the callback — do NOT call the outer `client.model.op()`
 *     inside the transaction (that would run on a different connection without the
 *     tenant GUC and return empty / wrong results under RLS).
 *
 *  2) STANDALONE — a single `client.model.op()` auto-wraps itself in one transaction
 *     with context set. Convenient for one-off calls, but it pays a full transaction
 *     per call, so never fire many of these back-to-back; use path #1 instead.
 */
export function getTenantPrisma(companyId: string, role?: string) {
  return prisma.$extends({
    client: {
      async $transaction<T>(
        fn: (tx: Prisma.TransactionClient) => Promise<T>,
        options?: {
          maxWait?: number;
          timeout?: number;
          isolationLevel?: Prisma.TransactionIsolationLevel;
        }
      ): Promise<T> {
        // Re-entrant: already inside an RLS transaction → run within it, no re-setup.
        if (rlsStorage.getStore()) {
          return prisma.$transaction(fn as any, options as any) as any;
        }
        return prisma.$transaction(async (tx) => {
          await setTenantContext(tx, companyId, role);
          return rlsStorage.run(true, () => fn(tx));
        }, options as any) as any;
      },
    },
    query: {
      $allModels: {
        async $allOperations({ model, operation, args, query }) {
          // Inside an active RLS transaction — context already set, run directly.
          if (rlsStorage.getStore()) {
            return query(args);
          }
          // Standalone call — one transaction, context set once.
          return prisma.$transaction(async (tx) => {
            await setTenantContext(tx, companyId, role);
            return rlsStorage.run(true, () => (tx as any)[model][operation](args));
          });
        },
      },
    },
  });
}
