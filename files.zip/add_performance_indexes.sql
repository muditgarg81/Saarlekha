-- ============================================================================
-- SaarLekha — performance indexes
-- ============================================================================
-- Postgres does NOT auto-index foreign keys (only primary keys and @unique
-- columns). These target the columns actually filtered/joined on the hot
-- dashboard and tenant query paths, where RLS forces a company_id filter on
-- every query.
--
-- Index names follow Prisma's "{Table}_{cols}_idx" convention, so if you later
-- add the matching @@index() lines to schema.prisma (see PERFORMANCE_FIXES.md),
-- Prisma sees them as already present and stays in sync — no duplicates, no drift.
--
-- For very large LIVE tables, replace each CREATE INDEX with
--   CREATE INDEX CONCURRENTLY ...
-- and run the statements one at a time, OUTSIDE a transaction block.
-- ============================================================================

-- ReportEntry: filtered by company_id (+ entry_date), department_id; joined via format_version_id
CREATE INDEX IF NOT EXISTS "ReportEntry_company_id_entry_date_idx" ON "ReportEntry" ("company_id", "entry_date");
CREATE INDEX IF NOT EXISTS "ReportEntry_department_id_idx"          ON "ReportEntry" ("department_id");
CREATE INDEX IF NOT EXISTS "ReportEntry_format_version_id_idx"      ON "ReportEntry" ("format_version_id");

-- ProductionRecord: filtered by company_id (+ date), operator_id (dept scope), machine_id
CREATE INDEX IF NOT EXISTS "ProductionRecord_company_id_date_idx"   ON "ProductionRecord" ("company_id", "date");
CREATE INDEX IF NOT EXISTS "ProductionRecord_operator_id_idx"       ON "ProductionRecord" ("operator_id");
CREATE INDEX IF NOT EXISTS "ProductionRecord_machine_id_idx"        ON "ProductionRecord" ("machine_id");

-- Manpower: count by company (RLS), findMany by department
CREATE INDEX IF NOT EXISTS "Manpower_company_id_idx"                ON "Manpower" ("company_id");
CREATE INDEX IF NOT EXISTS "Manpower_department_id_idx"             ON "Manpower" ("department_id");

-- JobOrder: count of OPEN per company; customer lookups
CREATE INDEX IF NOT EXISTS "JobOrder_company_id_status_idx"         ON "JobOrder" ("company_id", "status");
CREATE INDEX IF NOT EXISTS "JobOrder_customer_id_idx"               ON "JobOrder" ("customer_id");

-- Machine: company + department scope
CREATE INDEX IF NOT EXISTS "Machine_company_id_idx"                 ON "Machine" ("company_id");
CREATE INDEX IF NOT EXISTS "Machine_department_id_idx"              ON "Machine" ("department_id");

-- Maintenance join path: ReportEntry -> ReportFormatVersion -> ReportFormat (type)
CREATE INDEX IF NOT EXISTS "ReportFormatVersion_format_id_idx"      ON "ReportFormatVersion" ("format_id");
CREATE INDEX IF NOT EXISTS "ReportFormat_company_id_type_idx"       ON "ReportFormat" ("company_id", "type");

-- Other tenant-scoped tables
CREATE INDEX IF NOT EXISTS "Customer_company_id_idx"                ON "Customer" ("company_id");
CREATE INDEX IF NOT EXISTS "AuditLogEntry_company_id_timestamp_idx" ON "AuditLogEntry" ("company_id", "timestamp");
